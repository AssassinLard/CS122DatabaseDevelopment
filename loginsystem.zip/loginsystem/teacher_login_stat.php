
<html>
  <head>
        <meta charset="utf-8">
        <link href="reset.css" rel="stylesheet">
        <link href="style_login.css" rel="stylesheet">
        <title>Teacher Login</title> 
    </head>


	<?php
                        $user = 'root';
                        $pass = '';
                        $db = 'dtrdb';
                        $db = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");
						if ($db->connect_errno) {
						  
						   echo "Database is off-line or user credential is invalid.  Please Wait...";						
						   header('Refresh: 2; URL=MyError.html');
						 exit;
						}
						
    		
                  
						
						
						// username and password sent from form 
						$myusername=$_POST['myusername']; 
						$mypassword=$_POST['mypassword']; 
						
						

						
						$myusername = stripslashes($myusername);
						$mypassword = stripslashes($mypassword);			
						

						$sql = "SELECT  employeeno, CONCAT(fname,' ',lname) 'FULLNAME' FROM employee WHERE employeeno='$myusername' AND pincode='$mypassword' AND position='FACULTY' LIMIT 1;";
                        $result = mysqli_query($db, $sql);
                        $resultCheck = mysqli_num_rows($result);
						$row = mysqli_fetch_assoc($result);

						

						// If result matched $myusername and $mypassword, table row must be 1 row
						if($resultCheck==1){
							// Insert or Update Record then Show Pop-Up	
							date_default_timezone_set("Asia/Singapore"); //Please edit this \wamp64\bin\apache\apache2.4.27\bin\php.ini
							$thedate=date("Y/m/d");
							$thetime=date("h:i:00");
							//echo "$thetime</br>";
							
							$sql = "SELECT employeeno FROM DTR WHERE employeeno='$myusername' AND DATE='$thedate' LIMIT 1;";
							$result = mysqli_query($db, $sql);
							$resultCheck = mysqli_num_rows($result);
							
							
							$IsNewRec="0";	
							
							
							if($resultCheck==1) 
							{	
								//Update Time-Out
								$sql = "UPDATE DTR SET timeOut ='$thetime' WHERE employeeno='$myusername' AND DATE='$thedate';";
							}	
							ELSE
							{	//Insert Record
								$IsNewRec="1";
								$sql = "INSERT INTO DTR(reference_number, employeeno, date, timeIn, absent, onLeave ) VALUES ('$myusername','$myusername','$thedate','$thetime',0,0);";
							}
							
							if ($db->query($sql) === TRUE)
							{
								if ($IsNewRec=="1")
									$LogResult="Employee No:  " . $row["employeeno"] . " Employee Name: " . $row["FULLNAME"] . " Time In: $thetime";
								else
								{
										$sql2 = "SELECT timeIn FROM DTR WHERE employeeno='$myusername' AND DATE='$thedate' LIMIT 1;";
										$result2 = mysqli_query($db, $sql2);
										$resultCheck2 = mysqli_num_rows($result2);
										$rowDTR = mysqli_fetch_assoc($result2);
										$LogResult="Employee No:  " . $row["employeeno"] . " Employee Name: " . $row["FULLNAME"] . " Time In: ".$rowDTR["timeIn"] . " Time Out: $thetime";
								}		
							}
							else
							{
								
							}
							
								
							
							
						}
						else {
						mysqli_close($db);	
						echo "Wrong Username or Password for Teacher.  Please wait...";						
						header('Refresh: 3; URL=MyError.html');
						exit;
						}
					
						mysqli_close($db);
       ?>
	   
	
    
    <body>
		</br></br></br></br>
		
		<!--<div class="container"> -->
		
		
		<center>
		</br></br></br></br></br></br>
		 <?php
					Echo "$LogResult"
		 ?>
		<div id = "buttons">
			<btn id = "Back">
				
				<a href="index.html">Back</a>
			</btn>
		 </div>
		
		</center>
		<!-- </div> -->
	</body>
	   
	   </html>
	   